#include "softi2c.h"




void Soft_IIC_Start(){
	SCL=1;
	SDA=1;
	_nop_();_nop_();
	SDA=0;
	_nop_();_nop_();
	SCL=0;
}

	
void Soft_IIC_Ack(){
	SDA=1;
	SCL=0;
	_nop_();_nop_();
	
	SCL=1;
	_nop_();_nop_();
	
	SCL=0;
}

void Soft_IIC_Stop(){
	SDA=0;
	SCL=1;
	_nop_();_nop_();
	
	SDA=1;
	_nop_();_nop_();
}


void Soft_IIC_WriteByte(u8 IIC_Data){
	unsigned char i;
	unsigned char m,da;
	da=IIC_Data;
	
	SCL=0;;
	for(i=0;i<8;i++)		
	{
			m=da;
		//	OLED_SCLK_Clr();
		m=m&0x80;
		if(m==0x80)
		{
			SDA=1;}
		else {
			SDA=0;
		}
		da=da<<1;
		SCL=1;
		_nop_();_nop_();
		SCL=0;
		
		}
	
	
}

void Soft_IIC_Mem_Write(u8 DevAddr,u8 Cmd,u8 *Pdata,u8 DataSize){
	int i;
	Soft_IIC_Start();
	Soft_IIC_WriteByte(DevAddr);
	Soft_IIC_Ack();
	Soft_IIC_WriteByte(Cmd);
	Soft_IIC_Ack();
	for(i=0;i<DataSize;i++){
		Soft_IIC_WriteByte(Pdata[i]);
		Soft_IIC_Ack();
	}
	Soft_IIC_Stop();
}

void Soft_IIC_Write(u8 DevAddr,u8 Cmd,u8 dat){
	Soft_IIC_Start();
	Soft_IIC_WriteByte(DevAddr);
	Soft_IIC_Ack();
	Soft_IIC_WriteByte(Cmd);
	Soft_IIC_Ack();
	
	Soft_IIC_WriteByte(dat);
	Soft_IIC_Ack();
	
	Soft_IIC_Stop();
}