#ifndef _GAME_H_
#define _GAME_H_


#include "oled.h"



void Draw_background();
void Draw_Lose();
void Draw_Menu();

void OLED_ShowNum(unsigned char x,unsigned char y,int num);
void OLED_ShowChinese(unsigned char x,unsigned char y);
void Game_DrawDino(unsigned char x,unsigned char y,unsigned char interval);


#endif