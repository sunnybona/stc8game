#include <STC8G.H>
#include <intrins.h>
#define u8 unsigned char

sbit SCL=P3^2;
sbit SDA=P3^3;



void Delay5us(void);	//@11.0592MHz

void Soft_IIC_Start();
void Soft_IIC_Ack();
void Soft_IIC_Stop();
void Soft_IIC_WriteByte(u8 IIC_Data);
void Soft_IIC_Mem_Write(u8 DevAddr,u8 Cmd,u8 *Pdata,u8 DateSize);
void Soft_IIC_Write(u8 DevAddr,u8 Cmd,u8 dat);