#include "oled.h"

u8 xdata OLED_GRAM[8][128]={0};

u8 code OLED_INIT_COMMAND[28]={
//	0xAE,
//	0x00,//---set low column address
//	0x10,//---set high column address
//	0x40,//--set start line address  
//	0xB0,//--set page address
//	0x81, // contract control
//	0xFF,//--128   
//	0xA1,//set segment remap 
//	0xA6,//--normal / reverse
//	0xA8,//--set multiplex ratio(1 to 64)
//	0x3F,//--1/32 duty
//	0xC8,//Com scan direction
//	0xD3,//-set display offset
//	0x00,//
//	
//	0xD5,//set osc division
//	0xF0,//
//	
//	0xD8,//set area color mode off
//	0x05,//
//	
//	0xD9,//Set Pre-Charge Period
//	0xF1,//
//	
//	0xDA,//set com pin configuartion
//	0x12,//
//	
//	0xDB,//set Vcomh
//	0x30,//
//	
//	0x8D,//set charge pump enable
//	0x14,//
//	
//	0xAF,//--turn on oled panel
	0xAE,//--turn off oled panel
	0x00,//---set low column address
	0x10,//---set high column address
	0x40,//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
	0x81,//--set contrast control register
	0xCF,// Set SEG Output Current Brightness
	0xA1,//--Set SEG/Column Mapping     0xa0������������?? 0xa1?y3��
	0xC8,//Set COM/Row Scan Direction   0xc0��???����?? 0xc8?y3��
	0xA6,//--set normal display
	0xA8,//--set multiplex ratio(1 to 64)
	0x3f,//--1/64 duty
	0xD3,//-set display offset	Shift Mapping RAM Counter (0x00~0x3F)
	0x00,//-not offset
	0xd5,//--set display clock divide ratio/oscillator frequency
	0xf0,//--set divide ratio, Set Clock as 100 Frames/Sec
	0xD9,//--set pre-charge period
	0xF1,//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
	0xDA,//--set com pins hardware configuration
	0x12,
	0xDB,//--set vcomh
	0x40,//Set VCOM Deselect Level
	0x20,//-Set Page Addressing Mode (0x00/0x01/0x02)
	0x02,//
	0x8D,//--set Charge Pump enable/disable
	0x14,//--set(0x10) disable
	0xA4,// Disable Entire Display On (0xa4/0xa5)
	0xA6,// Disable Inverse Display On (0xa6/a7) 
	0xAF,


};

u8 bdata dat;
sbit d7=dat^7;
sbit d6=dat^6;
sbit d5=dat^5;
sbit d4=dat^4;
sbit d3=dat^3;
sbit d2=dat^2;
sbit d1=dat^1;
sbit d0=dat^0;
void Delay1000ms(void)	//@22.1184MHz
{
	unsigned char data i, j, k;

	i = 113;
	j = 53;
	k = 228;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

void OLED_Clear(){
	u8 i,n;
	for(i=0;i<8;i++){
		for(n=0;n<128;n++){
			OLED_GRAM[i][n]=0x00;
		}
	}
}



void OLED_DrawPoint(u8 x,u8 y)
{
	u8 i,m,n;
	if(x>127 || x<0 || y<0 || y>63) return;
	
	i=y/8;
	m=y%8;
	n=1<<m;
	
	OLED_GRAM[i][x] |=n; 
}






void OLED_DrawBitmap_v1(int x,int y,unsigned char *bitmap,unsigned char w,unsigned char h){
	u8 i,n,m,k,temp;
	k=0;
	for(i=0;i<h/8;i++){
		for(n=0;n<w;n++){
			if(y%8==0 && x+n>=0 && x+n<128){
				
				OLED_GRAM[y/8+i][x+n]=bitmap[k];
				
			}else{
			temp=bitmap[k];
			for(m=0;m<8;m++){
				if((temp>>m) & 0x01) OLED_DrawPoint(x+n,y+m+i*8);
			}
		  }
			k++;
		}
	}
		
}


void OLED_DrawBitmap(int x,int y,unsigned char *bitmap,unsigned char w,unsigned char h){
	int i,n,m,k,temp;
	k=0;
	m=y%8;
	for(i=0;i<h/8;i++){
		for(n=0;n<w;n++){
			
			if(x+n>=0 && x+n<128 && y/8+i>=0 && y/8+i<8){
				temp=bitmap[k];
				OLED_GRAM[y/8+i][x+n] |=temp<<(m);
				if( m!=0  && y/8+i+1>=0 && y/8+i+1<8){
					temp=bitmap[k];
					OLED_GRAM[y/8+i+1][x+n] |=temp>>(8-m);
				}
					
				
			}
			
			k++;
		}
	}
		
}
void OLED_Refresh(void)
{
	u8 i,n;
	
	for(i=0;i<8;i++)
	{
	  
		Soft_IIC_Write(DevAddr,OLED_CMD,0xb0+i);

		Soft_IIC_Write(DevAddr,OLED_CMD,0x00);
		Soft_IIC_Write(DevAddr,OLED_CMD,0x10);
		Soft_IIC_Start();
		Soft_IIC_WriteByte(DevAddr);
		Soft_IIC_Ack();
		Soft_IIC_WriteByte(0X40);
		Soft_IIC_Ack();
	   for(n=0;n<128;n++)
		{	
			dat=OLED_GRAM[i][n];
			SCL=0;
			_nop_();_nop_();
			SDA=d7;
			_nop_();_nop_();_nop_();_nop_();
			SCL=1;
			_nop_();_nop_();
			SCL=0;
			_nop_();_nop_();
			SDA=d6;
			_nop_();_nop_();_nop_();_nop_();
			SCL=1;
			_nop_();_nop_();
			SCL=0;
			_nop_();_nop_();
			SDA=d5;
			_nop_();_nop_();_nop_();_nop_();
			SCL=1;
			_nop_();_nop_();
			SCL=0;
			_nop_();_nop_();
			SDA=d4;
			_nop_();_nop_();_nop_();_nop_();
			SCL=1;
			_nop_();_nop_();
			SCL=0;
			_nop_();_nop_();
			SDA=d3;
			_nop_();_nop_();_nop_();_nop_();
			SCL=1;
			_nop_();_nop_();
			SCL=0;
			_nop_();_nop_();
			SDA=d2;
			_nop_();_nop_();_nop_();_nop_();
			SCL=1;
			_nop_();_nop_();
			SCL=0;
			_nop_();_nop_();
			SDA=d1;
			_nop_();_nop_();_nop_();_nop_();
			SCL=1;
			_nop_();_nop_();
			SCL=0;
			_nop_();_nop_();
			SDA=d0;
			_nop_();_nop_();_nop_();_nop_();
			SCL=1;
			_nop_();_nop_();
			SCL=0;
			_nop_();_nop_();
			Soft_IIC_Ack();
//			Soft_IIC_Mem_Write(DevAddr,OLED_DATA,OLED_GRAM[i],128);
		}
		Soft_IIC_Stop();
  }

}
void OLED_Init(){
	Soft_IIC_Mem_Write(DevAddr,OLED_CMD,OLED_INIT_COMMAND,28);
}


void Draw_Ground(unsigned char gpos,u8 * gb){
  u8 n;
	
	for(n=0;n<128;n++){
   
			OLED_GRAM[7][n]=gb[(gpos+n)%128];
	}
}



