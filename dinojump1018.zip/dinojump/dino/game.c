#include "game.h"
#include "font.h"




void Draw_background(){
	unsigned char i;
//	for(i=0;i<128;i++){
//		OLED_DrawPoint(i,0);
//		OLED_DrawPoint(i,63);
//	}
	for(i=0;i<64;i++){
		OLED_DrawPoint(0,i);
//		OLED_DrawPoint(127,i);
		OLED_DrawPoint(81,i);
	}
	for(i=0;i<5;i++){
		OLED_DrawBitmap(86+i*8,0,ztscore[i],8,16);
	}
	
	for(i=0;i<5;i++){
		OLED_DrawBitmap(86+i*8,32,ztlevel[i],8,16);
	}
}


void Draw_Menu(){
	unsigned char i;
	for(i=0;i<9;i++){
		OLED_DrawBitmap(40+i*8,16,zt_dino[i],8,16);
	}
//	for(i=0;i<12;i++){
//		OLED_DrawBitmap(16+i*8,32,ztkeyb[i],8,16);
//	}
	
	for(i=0;i<11;i++){
		OLED_DrawBitmap(16+i*8,48,ztkeya[i],8,16);
	}
	
}

void Draw_Lose(){
	unsigned char i;
	for(i=0;i<9;i++){
		OLED_DrawBitmap(28+i*8,16,ztover[i],8,16);
	}
}

void OLED_ShowNum(unsigned char x,unsigned char y,int num){
	unsigned char q,b,s,g;
//	w=num/10000%10;
	q=num/1000%10;
	b=num/100%10;
	s=num/10%10;
	g=num%10;
//	OLED_DrawBitmap(x+0,y,yhnum[w],8,16);
	OLED_DrawBitmap(x+0,y,yhnum[q],8,16);
	OLED_DrawBitmap(x+8,y,yhnum[b],8,16);
	OLED_DrawBitmap(x+16,y,yhnum[s],8,16);
	OLED_DrawBitmap(x+24,y,yhnum[g],8,16);
}

void OLED_ShowChinese(unsigned char x,unsigned char y){
	OLED_DrawBitmap(x+0,y,zpl[0],16,16);
	OLED_DrawBitmap(x+16,y,zpl[1],16,16);
	OLED_DrawBitmap(x+32,y,zpl[2],16,16);
}


//void Game_DrawDino(unsigned char x,unsigned char y,unsigned char interval){
//	unsigned char dino_frame;
//	dino_frame++;
//	
//	if(dino_frame>0 && dino_frame<interval) OLED_DrawBitmap(x,y,actor_dino[0],16,16);
//	if(dino_frame>=interval && dino_frame<2*interval) OLED_DrawBitmap(x,y,actor_dino[1],16,16);
//	if(dino_frame>=2*interval && dino_frame<3*interval)	OLED_DrawBitmap(x,y,actor_dino[2],16,16);
//	if(dino_frame>=3*interval) dino_frame=0;
//}