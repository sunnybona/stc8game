#include "softi2c.h"

#define DevAddr 0X78
#define OLED_CMD 0X00
#define OLED_DATA 0X40



void Delay1000ms(void);
void OLED_Init();
void OLED_Clear();

void OLED_On(void);
void OLED_Refresh();

void OLED_DrawPoint(unsigned char x,unsigned char y);
void OLED_FillRect(int x,int y,unsigned char w,unsigned char h);
void OLED_DrawBitmap(int x,int y,unsigned char *bitmap,unsigned char w,unsigned char h);

void Draw_Ground(unsigned char gpos,u8 * gb);
void Draw_Yun(unsigned char ypos,u8 * yun);