#include "game.h"
#include "actor.h"

unsigned char dino_frame,dino_num;
struct ACTOR{
	int x;
	int y;
	unsigned char living;
};


struct ACTOR Game_Yun1;
struct ACTOR Game_Yun2;
struct ACTOR Game_Xrz16;
struct ACTOR Game_Xrz8;
struct ACTOR Game_Flydino;
struct ACTOR Game_Dino;
unsigned char ground_pos,yun_speed;

bit key_left,key_right,key_up,key_down,key_a,key_b,game_state,xrz16,xrz8,dino_low;
unsigned int score;
		
unsigned int frame_start;
unsigned int framefreq;
int res,dino_state;
int dino_jump_speed,frame_dino_jump;
unsigned char dino_pos_y[9]={47,32,23,16,11,16,23,32,47};
void ADCInit()
{
	P_SW2 |= 0x80;
	ADCTIM = 0x3f; //???? ADC ??????
	P_SW2 &= 0x7f;
	ADCCFG = 0x2f; //???? ADC ?????????/2/16
	ADC_CONTR = 0x85; //??? ADC ???,?????? 15 ???
}

int ADCRead()
{
	int res;

	ADC_CONTR |= 0x40; //???? AD ???
	_nop_();
	_nop_();
	while (!(ADC_CONTR & 0x20)); //??? ADC ?????
	ADC_CONTR &= ~0x20; //???????
	res = (ADC_RES << 8) | ADC_RESL; //??? ADC ???
	return res;
}


void Game_Init(){
	dino_frame=0;
	dino_num=0;
	dino_state=0;
	Game_Dino.x=16;
	Game_Dino.y=48;
	Game_Dino.living=1;
	dino_jump_speed=0;
	Game_Yun1.x=135;
	Game_Yun1.y=16;
	Game_Yun2.x=160;
	Game_Yun2.y=20;
	Game_Xrz16.x=16;
	Game_Xrz16.y=48;

	Game_Xrz8.x=256;
	Game_Xrz8.y=56;
	
	Game_Flydino.x=80;
	Game_Flydino.y=40;
	game_state=1;
}

void Game_Input(){
	int i;
	res = 0;
	for (i=0; i<8; i++)
	{
	res += ADCRead(); //??? 8 ??????
	}
	res >>= 3;
	if(res>1000){
		key_left=1;
	}else if(res>720 && res<750){
		key_up=1;
	}else if(res>540 && res <560){
		key_right=1;
	}else if(res>410 && res<430){
		key_a=1;
	}else if(res>300 && res<330){
		
		key_b=1;
	}else if(res>210 && res<230){
		key_down=1;
	}
}

void Menu_Update(){
	if(key_left){
		
		key_left=0;
	}
	if(key_up ){
		
		key_up=0;
	}
	if(key_right){
		
		key_right=0;
	}
	if(key_down){
		
		key_down=0;
	}
	if(key_a){
		
		
		Game_Init();
		key_a=0;
		
	}
	if(key_b){
		
		key_b=0;
		
	}
}

void Game_Check(){
	if(Game_Dino.x+12>Game_Xrz16.x && Game_Dino.x<Game_Xrz16.x+12 && Game_Dino.y+12>Game_Xrz16.y) xrz16=1;
	
	if(Game_Dino.x+12>Game_Xrz8.x && Game_Dino.x<Game_Xrz8.x+6 && Game_Dino.y+12>Game_Xrz8.y) xrz8=1;
	if(xrz16==1 || xrz8==1) {
		
		
		
		Draw_Lose();
		OLED_Refresh();
		Delay1000ms();
		Delay1000ms();
		Delay1000ms();
		game_state=0;
		xrz16=0;
		xrz8=0;
	}
	
}	

void Game_Update(){
//	Game_Check();
	dino_frame++;
	yun_speed++;
	ground_pos++;
	if(key_left){
		
		key_left=0;
	}
	if(key_up){
		
		dino_state=1;
		frame_dino_jump=0;
		dino_jump_speed=16;
		key_up=0;
	}
	if(key_right){
		
		key_right=0;
	}
	if(key_down){
		dino_low=1;
		key_down=0;
	}
	if(key_a){
		
		
		
		key_a=0;
		
	}
	if(key_b){
		
		key_b=0;
		
	}
	
	if(dino_state){
		dino_jump_speed++;
		if(dino_jump_speed>15) {
			
			Game_Dino.y=dino_pos_y[frame_dino_jump];
			frame_dino_jump++;
			if(frame_dino_jump==9){
				
				dino_state=0;
				score++;
			}
			dino_jump_speed=0;
		}
		
		
	}
		
	
	if(dino_frame%10==0){
		dino_num++;
	}
	if(dino_num==2) dino_num=0;
	if(yun_speed%10==0){
		Game_Yun1.x--;
		Game_Yun2.x--;
		
	}
	Game_Flydino.x--;
	if(Game_Flydino.x+16<0) Game_Flydino.x=255;
	
	
	if(Game_Yun1.x+16<0) Game_Yun1.x=128;
	if(Game_Yun2.x+16<0) Game_Yun2.x=160;

	Game_Xrz16.x--;
	if(Game_Xrz16.x+16<0) Game_Xrz16.x=144;
	Game_Xrz8.x--;
	if(Game_Xrz8.x+8<0) Game_Xrz8.x=256;
	//		if(dino_frame>15) dino_frame=0;
	//		if(dino_frame>0 && dino_frame<=5) dino_num=0;
	//		if(dino_frame>5 && dino_frame<=10) dino_num=1;
	//		if(dino_frame>10 && dino_frame<=15)	dino_num=2;
}

void Game_Draw(){
	OLED_Clear();
	//		Draw_Yun(yun_pos,actor_yun);
	Draw_Ground(ground_pos,actor_ground);
	OLED_DrawBitmap(Game_Yun1.x,Game_Yun1.y,actor_yun,16,8);
	OLED_DrawBitmap(Game_Yun2.x,Game_Yun2.y,actor_yun,16,8);
	OLED_DrawBitmap(Game_Xrz16.x,Game_Xrz16.y,actor_xrz16,16,16);
	OLED_DrawBitmap(Game_Xrz8.x,Game_Xrz8.y,actor_xrz8,8,8);
	 OLED_DrawBitmap(Game_Flydino.x,Game_Flydino.y,actor_flydino[dino_num],16,16);
	if(dino_low){
		OLED_DrawBitmap(Game_Dino.x,Game_Dino.y+8,actor_dino_low,32,8);
		dino_low=0;
	}
	else OLED_DrawBitmap(Game_Dino.x,Game_Dino.y,actor_dino_16[dino_num],16,16);
	OLED_ShowNum(95,0,score);
		
		
	OLED_Refresh();
}

void Menu_Draw(){
	OLED_Clear();
	Draw_Menu();
	OLED_DrawBitmap(0,16,actor_start32,32,32);
//	OLED_ShowNum(40,32,res);
	OLED_Refresh();
}
void main(){
	
	P3M0=0X00;
	P3M1=0X00;
	P5M0 &= ~0x30;
	P5M1 |= 0x30; 
	
	ADCInit();
	OLED_Init();
	Game_Init();
	OLED_Clear();
	Draw_Menu();
	OLED_DrawBitmap(0,16,actor_start32,32,32);
	OLED_Refresh();
	game_state=0;
	res=0;
	while(1){
		Game_Input();
		if(game_state){
			
			Game_Update();
			Game_Draw();
			
		}else{
			
			Menu_Update();
			Menu_Draw();
		}
		
	}
}